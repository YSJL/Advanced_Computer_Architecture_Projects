import java.lang.Math;
import java.util.ArrayList;

public class simulator {
    public static void main(String[] args) {
        ArrayList<String> config = new ArrayList<>();
        for (int c = 0; c < 4; c++) {
            for (int p = 9; p < 32; p++) {
                for (int l = 9; l < 32; l++) {
                    for (int n = 8; n < 32; n++) {
                        for (int g = 32; g < 65; g++) {
                            double Yp = p * Math.pow(2, l) + 2 * Math.pow(2, p);
                            double Perc = (Math.ceil(Math.log(1.93 * g + 14) / Math.log(2)) + 1) * (g + 1) * Math.pow(2, n);
                            if (Yp >= 3 * Math.pow(2, 14) && Perc >= 3 * Math.pow(2, 14) && Yp + Perc <= 3 * Math.pow(2, 16)) {
                                config.add("PLNGC_" + p + "_" + l + "_" + n + "_" + g + "_" + c);
                                System.out.println("flags_" + "PLNGC_" + p + "_" + l + "_" + n + "_" + g + "_" + c + "='-M 3 -P " + p + " -L " + l + " -N " + n + " -G " + g + " -C " + c + "'");
                            }
                        }
                    }
                }
            }
        }
        System.out.print("configs=( ");
        for (int i = 0; i < config.size(); i++) {
            System.out.print(config.get(i) + " ");
        }
        System.out.print(")\n");
    }
}
