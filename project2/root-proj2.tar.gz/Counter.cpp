#include "Counter.hpp"
#include <cstdint>

// ===================================================================
// Documentation for these methods are in the header file, Counter.hpp
// ===================================================================

Counter::Counter(uint64_t width) {
    // TODO: implement me
}

void Counter::update(bool taken) {
    // TODO: implement me
}

uint64_t Counter::get() {
    // TODO: implement me
    return 0;
}

bool Counter::isTaken() {
    // TODO: implement me
    return false;
}

void Counter::setCount(uint64_t count) {
    // TODO: implement me
}

bool Counter::isWeak() {
    // TODO: implement me
    return false;
}

void Counter::reset(bool taken) {
    // TODO: implement me
}
