#!/bin/bash
exec ./branchsim "$@"
